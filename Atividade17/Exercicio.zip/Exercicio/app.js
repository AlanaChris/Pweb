let app = require('./app/config/server');
//carregando o módulo do servidor
let rotaHome = require('./app/routes/home');//só está definindo as rotas
rotaHome(app);//está executando
let texto = require('./modulo1'); //não precisa colocar modulo1.js ele já entende que é js

let rotaAdicionarUsuario = require('./app/routes/adicionar_usuario');
rotaAdicionarUsuario(app);

let rotaHistoria = require('./app/routes/historia');
rotaHistoria(app);

let rotaCursos = require('./app/routes/cursos');
rotaCursos(app);

let rotaProfessores = require('./app/routes/professores');
rotaProfessores(app);

/*poderia executar assim também*/
/*
let rotaAdicionarUsuario = require('./app/routes/adicionar_usuario')(app);
*/

app.listen(3000,function(){
    console.log('servidor iniciado');
});

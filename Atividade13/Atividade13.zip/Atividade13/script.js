const janela = document.getElementById("janela");
const statusTexto = document.getElementById("status");

let quebrada = false;

// Abrir janela
janela.addEventListener("mouseover", () => {
    if (!quebrada) {
        janela.src = "img/janela_aberta.png";
        statusTexto.innerText = "Janela Aberta";
    }
});

// Fechar janela
janela.addEventListener("mouseout", () => {
    if (!quebrada) {
        janela.src = "img/janela_fechada.png";
        statusTexto.innerText = "Janela Fechada";
    }
});

// Quebrar janela
janela.addEventListener("click", () => {
    janela.src = "img/janela_quebrada.png";
    statusTexto.innerText = "Janela Quebrada";

    quebrada = true;
});